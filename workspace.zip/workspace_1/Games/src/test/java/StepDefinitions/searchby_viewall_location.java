package StepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class searchby_viewall_location {
	WebDriver driver;
	private int total_records;
	@Given("^Launch the OpenBet Application$")
	public void Launch_the_OpenBet_Application()
	{
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://www.openbetcareers.com");
	}
	
	@When("^The user search by viewall location filter in the vacancies section$")
	public void The_user_search_by_viewall_location_filter_in_the_vacancies_section() throws InterruptedException
	{
		
		Thread.sleep(10);
		driver.findElement(By.linkText("Vacancies")).click();
		total_records=driver.findElements(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr/td[1]")).size();
		System.out.println("Total Count" + total_records);
		List<WebElement> element = driver.findElements(By.className("srSearchOptionText"));
	    for (int i = 0; i < element.size(); i++) {
	        String temp = element.get(i).getText();
	        if (temp.equals("Singapore")) {
	            element.get(i).click();             
	            break;
	        }
	    }
	    Thread.sleep(10);
	   // int particular_location_records=driver.findElements(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr/td[1]")).size();
	    List<WebElement> element_location = driver.findElements(By.className("srSearchOptionText"));
	    for (int i = 0; i < element_location.size(); i++) {
	        String temp_local = element_location.get(i).getText();
	        if (temp_local.equals("Singapore")) {
	        	element_location.get(i).click();             
	            break;
	        }
	    }
	    Thread.sleep(5);
	    List<WebElement> element_1 = driver.findElements(By.className("srSearchOptionListElementText"));
	    for (int i = 0; i < element_1.size(); i++) {
	        String temp_1 = element_1.get(i).getText();
	        if (temp_1.equals("View all")) {
	        	element_1.get(i).click();             
	            break;
	        }
	    }
	    
	    
	}
	@Then("^All the records in location is displayed$")
	public void All_the_records_in_location_is_displayed()
	{
		int view_all_records=driver.findElements(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr/td[1]")).size();
		if(total_records==view_all_records)
	    {
	    	System.out.println("Total View all count matches success");
	    }
	}
	@After
	public void close_driver()
	{
		driver.close();
	}

}
