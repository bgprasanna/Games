package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class job_description {
WebDriver driver;
	private String jobtitle;
	@Given("^Launch the Open Bet Application in Firefox$")
	public void Open_the_Firefox_and_launch_the_application() throws InterruptedException
	{		
		System.out.println("Entering");
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://www.openbetcareers.com");
		Thread.sleep(5);		
	}
	@When("^The User searched for the vacancy in the vacancies area$")
	public void The_User_searched_for_the_vacancy_in_the_vacancies_area() throws InterruptedException
	{
		driver.findElement(By.linkText("Vacancies")).click();
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys("Senior");
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys(Keys.RETURN);
		Thread.sleep(10);
		jobtitle=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[1]")).getText();
		
	}
	@Then("^The vacancy is navigated to job description page$")
	public void The_vacancy_is_navigated_to_job_description_page()
	{
		driver.navigate().to("https://www.smartrecruiters.com/SGDigital/743999668454718-senior-software-engineer-java-");
		String title_desc=driver.findElement(By.xpath("html/body/div[3]/div/div/div/main/h1")).getText();
		if(jobtitle.equalsIgnoreCase(title_desc))
		{
			System.out.println("Job Title Matched");
		}
		boolean iaminterested=driver.findElement(By.id("st-apply")).isDisplayed();
		if(iaminterested)
		{
			System.out.println("I am Interested button is displayed");
		}
		boolean refer=driver.findElement(By.id("st-reffer")).isDisplayed();
		if(refer)
		{
			System.out.println("Refer button is displayed");
		}
	}
	@After
	public void close_driver()
	{
		driver.close();
	}

}
