package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class jobtitle_location {
	WebDriver driver;
	
	@Given("^Launch the Open Bet Application$")
	public void Open_the_Firefox_and_launch_the_application() throws InterruptedException
	{
		System.out.println("Entering");
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		 driver = new FirefoxDriver();
		driver.get("https://www.openbetcareers.com");
		Thread.sleep(5);
	}
	@When("^The User searched by using keywords in the search text box$")
	public void The_User_Searched_by_using_keywords_in_the_search_text_box()
	{
		driver.findElement(By.linkText("Vacancies")).click();
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys("Software");
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys(Keys.RETURN);
		
	}
	@Then("^The jobtitle and location are available in the search results$")
	public void The_jobtitle_and_location_are_available_in_the_search_results()
	{
		String get_titletext=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[1]/th[1]/nobr")).getText();
		boolean get_titlevalue=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[1]")).isDisplayed();
		int records_count=driver.findElements(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr/td[1]")).size();
		//boolean get_title_value=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[1]")).isDisplayed();
		String get_location_text=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[1]/th[2]/nobr")).getText();
		boolean get_location_value=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[2]")).isDisplayed();
		
		if(get_titletext.equalsIgnoreCase("Job Title"))
		{
			System.out.println("Title Available");
		}
		if(records_count>0)
		{
			System.out.println("Records Available"+ records_count);
		}
		if(get_location_text.equalsIgnoreCase("Location"))
		{
			System.out.println("Location text available");
		}
		if(get_titlevalue)
		{
			System.out.println("Job title result is available");
		}
		if(get_location_value)
		{
			System.out.println("Location result is available");
		}
		
	}
	@After
	public void close_driver()
	{
		driver.close();
	}

}
