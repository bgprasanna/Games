package StepDefinitions;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;




import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Navigate {
	
	WebDriver driver;
	
	@Given("^Open the Firefox and launch the application$")
	public void Open_the_Firefox_and_launch_the_application() throws InterruptedException
	{
		
		System.out.println("Entering");
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		 driver = new FirefoxDriver();
		driver.get("https://www.openbetcareers.com");
		Thread.sleep(5);
		
	}
	@When("^The Vacancy menu is clicked$")
	public void The_Vacancy_menu_is_clicked()
	{
		driver.findElement(By.linkText("Vacancies")).click();
	}
	@Then("^Vacancy menu is navigated to the open vacancies area$")
	public void Vacancy_menu_is_navigated_to_the_open_vacancies_area()
	{
		String vacancy_gettext=driver.findElement(By.xpath(".//*[@id='openbet']/article/div[5]/div/div/div[2]/h1")).getText();
		System.out.println(vacancy_gettext);
		String vacancy_value="Vacancies";
		if(vacancy_value.equals(vacancy_gettext))
		{
			System.out.println("Pass");	
		}		
	}
	
	@After
	public void close_driver()
	{
		driver.close();
	}
	

	
	

}
