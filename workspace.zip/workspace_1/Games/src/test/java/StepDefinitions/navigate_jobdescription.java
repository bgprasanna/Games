package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class navigate_jobdescription {
	
	WebDriver driver;
	@Given("^Launch the OpenBet Application$")
	public void Launch_the_Open_Bet_Application() throws InterruptedException
	{		
		System.out.println("Entering");
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://www.openbetcareers.com");
		Thread.sleep(5);
	}
	
	@When("^The User searched the results with keywords$")
	public void When_The_User_searched_the_results_with_keywords() throws InterruptedException
	{
		driver.findElement(By.linkText("Vacancies")).click();
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys("Engineer");
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys(Keys.RETURN);
		
	}
	@Then("^The Job title is redirected to the job description page$")
	public void The_Job_title_is_redirected_to_the_job_description_page() throws InterruptedException
	{
		Thread.sleep(10);
		String job_titlevalue=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[1]")).getText();
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[1]")).click();
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
		Thread.sleep(10);
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL,Keys.SHIFT,Keys.TAB);
		String desc_title=driver.getTitle();
		System.out.println("Job Tilte"+job_titlevalue);
		System.out.println("navigated title"+desc_title);
		if(desc_title.contains("Engineer"))
		{
			System.out.println("Page navigated to the job description page");
		}
		
	}
	@After
	public void close_driver()
	{
		driver.close();
	}


}
