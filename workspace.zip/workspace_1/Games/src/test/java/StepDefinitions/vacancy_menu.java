package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class vacancy_menu {
	
	WebDriver driver;
	private String search_text="Test";
	private String get_keyword;
	@Given("^Go to the text box$")
	public void Go_to_the_search_text_box()
	{
		System.out.println("Entering text box");		
		//String text_value=driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).getText();
		//System.out.println(text_value);
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		 driver = new FirefoxDriver();
		driver.get("https://www.openbetcareers.com");
	}
	@When("^The user typed the keywords in the search text box$")
	public void The_user_type_the_keywords_in_the_search_text_box() throws InterruptedException
	{		
		driver.findElement(By.linkText("Vacancies")).click();
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys(search_text);
		driver.findElement(By.xpath(".//*[@id='smartWidget0']/div/form/input[1]")).sendKeys(Keys.RETURN);
		Thread.sleep(20);
		get_keyword=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[1]")).getText();
		System.out.println(get_keyword);
	}
	@Then("^The corresponding keywords is available in the results$")
	public void The_corresponding_keywords_is_avaiable_in_the_results() throws InterruptedException
	{
		System.out.println(get_keyword);
		if(get_keyword.contains(search_text))
		{
			System.out.println("Text Search pass");
		}
	}
	@After
	public void close_driver()
	{
		driver.close();
	}

}
