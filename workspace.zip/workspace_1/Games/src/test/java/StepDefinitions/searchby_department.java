package StepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class searchby_department 
{
	WebDriver driver;
	@Given("^Launch OpenBet Application$")
	public void Launch_OpenBet_Application()
	{
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://www.openbetcareers.com");
	}
	@When("^The user search by department filter in the vacancies section$")
	public void The_user_search_by_department_filter_in_the_vacancies_section() throws InterruptedException
	{
		Thread.sleep(10);
		driver.findElement(By.linkText("Vacancies")).click();
		List<WebElement> element = driver.findElements(By.className("srSearchOptionText"));
	    for (int i = 0; i < element.size(); i++) {
	        String temp = element.get(i).getText();
	        if (temp.equals("Gaming")) {
	            element.get(i).click();             
	            break;
	        }
	    }
	}
	@Then("^The available records are filtered by department$")
	public void The_available_records_are_filtered_by_department() throws InterruptedException
	{
		System.out.println("Department Captured");
		Thread.sleep(10);
		String get_department=driver.findElement(By.xpath(".//*[@id='smartWidget0']/table/tbody/tr[2]/td[1]")).getText();
		if (get_department.contains("Gaming"))
		{
			System.out.println("Filtered by Gaming Department");
		}
	}
	@After
	public void close_driver()
	{
		driver.close();
	}

}
