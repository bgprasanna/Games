package com.Scientific.org.Games;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class FirstTest {
	
	@Test
	public void firstmethod()
	{
		System.out.println("Launched TestNG");
	}
	@Test
	public void login()
	{
		System.setProperty("webdriver.gecko.driver", "E:\\Tools\\Drivers\\geckodriver.exe");
		WebDriver driver  = new FirefoxDriver();
		driver.get("http://www.imdb.com");
	}

}
